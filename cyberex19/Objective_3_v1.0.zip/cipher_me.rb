require 'openssl'

def buildFiles(key)
    File.write('publickey.pem', key.to_pem)
    File.binwrite('flag.encrypted', key.public_encrypt(File.binread('flag.txt')))
end

def generateKeys(e)
    p = OpenSSL::BN.generate_prime(1024, false)
    q = OpenSSL::BN.new(e).mod_inverse(p)

    return p,q
end

def constructFiles(p,q,e)
    key = OpenSSL::PKey::RSA.new
    key.set_key(p.to_i * q.to_i, e, nil)
    buildFiles(key)
end

if caller.length == 0
    e = 65537
    while true
        p,q = generateKeys(e)
        next unless q.prime?
        constructFiles(p,q,e)
        break
    end
end
